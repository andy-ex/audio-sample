May 10, 2013                


Pure Tone Audio Test Wave Files:
-------------------------------------------------

This archive contains 5 test tone tracks. The tracks are pure sine wave tones at frequencies (labelled with file name) of:
  60, 250, 1kHz, 10kHz and 20kHz
All tracks are programatically synthesized 16bit/44.1 kHz wav files with almost full digital amplitude:  30,000 / 32,767   or  -0.8 dBFS
Track duration is 120 sec.
Also included is a track with zero (silence) digital amplitude to test background noise during an active playback.

Since these tracks are at almost full digital amplitude, EXERCISE CARE IN PLAYBACK. Always set the playback volume
at minimum level (particularly with headphone use) and increase the playback volume slowly to prevent damage to speakers.

These tracks are provided solely for testing of audio equipment purposes and may not be incorporated into any products without
permission from JavaScience Consulting.

JavaScience Consulting
http://www.jensign.com
mig@jensign.com


